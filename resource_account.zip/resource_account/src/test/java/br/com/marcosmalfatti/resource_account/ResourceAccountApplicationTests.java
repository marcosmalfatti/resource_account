package br.com.marcosmalfatti.resource_account;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ResourceAccountApplicationTests {

	@Test
	void contextLoads() {
	}

}
